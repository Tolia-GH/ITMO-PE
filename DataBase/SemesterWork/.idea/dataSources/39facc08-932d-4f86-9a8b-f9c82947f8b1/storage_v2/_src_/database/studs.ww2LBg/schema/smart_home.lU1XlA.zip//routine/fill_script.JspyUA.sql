create function fill_script() returns SETOF smart_home.script
    language plpgsql
as
$$
DECLARE
    i int = 0;
    st script_type[] = array ['CONDITIONAL','SCHEDULE'];
BEGIN
    while i < 1000000 loop
            if i < 500000 then
                insert into script(creator, script_type)  VALUES (i%1000+1,st[1]) ;
            elsif i < 1000000 then
                insert into script(creator, script_type)  VALUES (i%1000+1,st[2]) ;
            end if;
            i = i + 1;
        end loop;
    return query select * from script limit 500;
end;
$$;

alter function fill_script() owner to postgres;

