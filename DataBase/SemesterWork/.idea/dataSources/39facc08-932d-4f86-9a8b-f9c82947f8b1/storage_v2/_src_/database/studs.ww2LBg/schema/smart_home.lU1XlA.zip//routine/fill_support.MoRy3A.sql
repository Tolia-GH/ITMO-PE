create function fill_support() returns SETOF smart_home.supporter
    language plpgsql
as
$$
DECLARE
    i int = 0;
    names varchar(64)[] = array ['Peter','Bob','John','Tomas','Alex','Anna'];
BEGIN
    while i < 1000 loop
            insert into supporter(password, username) VALUES (floor(random()*100000),names[i%6+1]);
            i = i + 1;
        end loop;
    return query select * from supporter;
end;
$$;

alter function fill_support() owner to postgres;

