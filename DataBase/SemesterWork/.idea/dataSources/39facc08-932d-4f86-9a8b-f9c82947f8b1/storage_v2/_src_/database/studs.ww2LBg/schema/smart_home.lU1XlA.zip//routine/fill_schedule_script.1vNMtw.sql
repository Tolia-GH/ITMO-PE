create function fill_schedule_script() returns SETOF smart_home.schedule_script
    language plpgsql
as
$$ DECLARE
    i int = 0; BEGIN
    while i < 500000 loop
        insert into schedule_script(script_id, action_time, repeat_on_monday, repeat_on_tuesday, repeat_on_wednesday, repeat_on_thursday, repeat_on_friday, repeat_on_saturday, repeat_on_sunday) VALUES
            (i+50001,'8:00',true,true,true,true,true,false,false) ;
        i = i + 1;
        end loop;
    return query select * from schedule_script limit 500;
end;
$$;

alter function fill_schedule_script() owner to postgres;

