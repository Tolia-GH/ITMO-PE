create function fill_issue() returns SETOF smart_home.issue
    language plpgsql
as
$$
DECLARE
    i int = 0;
BEGIN
    while i < 30000 loop
            insert into issue(user_id, supporter_id, description, is_finished, issue_type) values (i%100000 + 1,i%1000 + 1,'test test', true,'BUGS');
            i = i + 1;
        end loop;
    return query select * from issue limit 500;
end;
$$;

alter function fill_issue() owner to postgres;

