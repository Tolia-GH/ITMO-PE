create function new_contact() returns trigger
    language plpgsql
as
$$
BEGIN
    IF ((SELECT COUNT(*) FROM contact WHERE phone_num = NEW.phone_num) > 0) THEN
        RAISE EXCEPTION 'This phone number is already in used';
    ELSIF ((SELECT COUNT(*) FROM contact WHERE email = NEW.email) > 0) THEN
        RAISE EXCEPTION 'This email is already in used';
    END IF;
    RETURN NEW;
END;
$$;

alter function new_contact() owner to postgres;

