create function fill_room() returns SETOF smart_home.address
    language plpgsql
as
$$
DECLARE
    i int = 0;
    rooms room_type[] = array ['KITCHEN','BEDROOM','BATHROOM','LIVING'];
BEGIN
    while i < 1000000 loop
            insert into room(house_id, area_size, height,room_type) VALUES (i+1,19,3,rooms[i%4+1]),
                                                                   (i+1,22,3,rooms[i%4+1]),
                                                                   (i+1,22,3,rooms[i%4+1]);
            i = i + 1;
        end loop;
    return query select * from address limit 500;
end;
$$;

alter function fill_room() owner to postgres;

