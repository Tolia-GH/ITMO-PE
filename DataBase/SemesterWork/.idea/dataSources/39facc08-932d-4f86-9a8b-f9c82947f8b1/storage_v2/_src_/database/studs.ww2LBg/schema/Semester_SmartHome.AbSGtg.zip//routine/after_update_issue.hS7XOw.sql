create function after_update_issue() returns trigger
    language plpgsql
as
$$
BEGIN
    IF((SELECT COUNT(*) FROM issue WHERE supporter_id = NEW.supporter_id AND issue.is_finished = false)>=3) THEN
        UPDATE supporter SET is_free = FALSE WHERE supporter.id = NEW.supporter_id;
    ELSIF((SELECT COUNT(*) FROM issue WHERE supporter_id = NEW.support_man_id and issue.is_finished = false)<3) THEN
        UPDATE supporter SET is_free = TRUE WHERE supporter.id = NEW.supporter_id;
    END IF;
    IF((SELECT COUNT(*) FROM issue where support_man_id = OLD.supporter_id AND issue.is_finished = false)>=3) THEN
        UPDATE supporter SET is_free = FALSE WHERE supporter.id = OLD.support_man_id;
    ELSIF((SELECT COUNT(*) FROM issue where supporter_id = OLD.supporter_id AND issue.is_finished = false)<3) THEN
        UPDATE supporter SET is_free = TRUE WHERE supporter.id = OLD.supporter_id;
    END IF;
    RETURN NEW;
END;
$$;

alter function after_update_issue() owner to postgres;

