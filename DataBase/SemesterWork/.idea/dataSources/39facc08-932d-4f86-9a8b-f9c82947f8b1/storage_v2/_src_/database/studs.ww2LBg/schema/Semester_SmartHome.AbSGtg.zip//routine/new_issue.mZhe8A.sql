create function new_issue() returns trigger
    language plpgsql
as
$$
BEGIN
    IF ((SELECT COUNT(*) FROM issue WHERE supporter_id = NEW.supporter_id AND issue.is_finished = FALSE) >3) THEN
        RAISE EXCEPTION 'You cannot dispatch this problem to a busy supporter';
    ELSIF ((SELECT COUNT(*) FROM issue WHERE supporter_id = NEW.supporter_id AND issue.is_finished = false) >= 3) THEN
        UPDATE supporter SET is_free = FALSE where supporter.id = NEW.supporter_id;
    END IF;
    Return NEW;
END;
$$;

alter function new_issue() owner to postgres;

