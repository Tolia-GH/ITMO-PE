create function fill_list_user_house() returns SETOF smart_home.list_user_house
    language plpgsql
as
$$ DECLARE
    i int = 0; BEGIN
    while i < 1000000 loop
            insert into list_user_house(user_id, house_id) values (i + 1, i+1); i = i + 1;
        end loop;
    return query select * from list_user_house limit 500; end;
$$;

alter function fill_list_user_house() owner to postgres;

