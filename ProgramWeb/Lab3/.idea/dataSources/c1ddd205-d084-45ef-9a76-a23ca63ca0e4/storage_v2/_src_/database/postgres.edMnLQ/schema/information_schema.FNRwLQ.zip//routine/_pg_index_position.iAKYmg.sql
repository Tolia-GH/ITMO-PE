create function _pg_index_position(oid, smallint) returns integer
    stable
    strict
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function _pg_index_position(oid, smallint) owner to postgres;

